package com.example.madlevel1task2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.madlevel1task2.databinding.TrueorfalseBinding


class trueorfalse : AppCompatActivity() {

    private lateinit var binding: TrueorfalseBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = TrueorfalseBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.button.setOnClickListener {
            checkAnswer()
        }
    }

        private fun checkAnswer() {
            val tf1 = binding.tf1.text.toString()
            val tf2 = binding.tf2.text.toString()
            val tf3 = binding.tf3.text.toString()
            val tf4 = binding.tf4.text.toString()

            //alle antwoorden correct
            if (tf1 == "T" && tf2 == "F" && tf3 == "F" && tf4 == "F" )  {
                Toast.makeText(this, getString(R.string.correct), Toast.LENGTH_LONG).show()
            }

            //een antwoord incorrect
            if (tf1 == "F" && tf2 == "F" && tf3 == "F" && tf4 == "F" ||
                tf1 == "T" && tf2 == "T" && tf3 == "F" && tf4 == "F" ||
                tf1 == "T" && tf2 == "F" && tf3 == "T" && tf4 == "F" ||
                tf1 == "T" && tf2 == "F" && tf3 == "F" && tf4 == "T" ){
                Toast.makeText(this, getString(R.string.incorrect1), Toast.LENGTH_LONG).show()
            }
            //twee antwoorden incorrect
            //case 1 de tf1
            if (tf1 == "F" && tf2 == "T" && tf3 == "F" && tf4 == "F" ||
                tf1 == "F" && tf2 == "F" && tf3 == "T" && tf4 == "F" ||
                tf1 == "F" && tf2 == "F" && tf3 == "F" && tf4 == "T" ||
            //case 2 de tf2
                tf1 == "T" && tf2 == "T" && tf3 == "T" && tf4 == "F" ||
                tf1 == "T" && tf2 == "T" && tf3 == "F" && tf4 == "T" ||
            //case 3 de tf3
                tf1 == "T" && tf2 == "T" && tf3 == "T" && tf4 == "F" ||
                tf1 == "T" && tf2 == "F" && tf3 == "T" && tf4 == "T" )
                {
                Toast.makeText(this, getString(R.string.incorrect2), Toast.LENGTH_LONG).show()
            }
            //drie antwoorden incorrect
            //case 1
             if(tf1 == "F" && tf2 == "T" && tf3 == "T" && tf4 == "F" ||
                tf1 == "F" && tf2 == "F" && tf3 == "T" && tf4 == "T" ||
                tf1 == "F" && tf2 == "T" && tf3 == "F" && tf4 == "T" ||
                //case 2
                tf1 == "T" && tf2 == "T" && tf3 == "T" && tf4 == "T" ||
                tf1 == "F" && tf2 == "T" && tf3 == "T" && tf4 == "F" )
            {
                Toast.makeText(this, getString(R.string.incorrect3), Toast.LENGTH_LONG).show()
            }
            if (tf1 == "F" && tf2 == "T" && tf3 == "T" && tf4 == "T" ) {
                Toast.makeText(this, getString(R.string.incorrect4), Toast.LENGTH_LONG).show()
            }
           // if(tf1!= "T" || tf1!= "F" || tf2!="T" || tf2!="F" || tf3!="T" || tf3!="F" || tf4!="T" || tf4!="F" ){
                   // Toast.makeText(this, getString(R.string.wrong), Toast.LENGTH_LONG).show()
               // }

        }
        }




